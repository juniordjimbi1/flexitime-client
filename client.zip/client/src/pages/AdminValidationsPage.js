import React from 'react';
import ManagerValidationsPage from './ManagerValidationsPage';
export default function AdminValidationsPage() {
  return <ManagerValidationsPage />; // même vue, l'API renverra tout pour ADMIN
}
